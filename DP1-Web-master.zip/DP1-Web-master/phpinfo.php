<?php

/**
 * Created by Davide Sordi
 * Using PhpStorm
 * Date: 11/06/2019
 * Time: 00.00
 */

phpinfo();